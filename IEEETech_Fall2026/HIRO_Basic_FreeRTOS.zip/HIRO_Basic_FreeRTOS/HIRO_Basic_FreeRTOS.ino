/*
 * File Name: HIRO_Basic_FreeRTOS.ino
 * Description: Basic FreeRTOS movement controller for the
 * H.I.R.O. Model TR-01-A by Takamori Robot.
 *
 * Author: Pedro Maya
 * Date Created: November 2nd, 2026
 *
 * This program uses FreeRTOS to separate serial communication,
 * robot movement, and LED control into three independent tasks.
 *
 * Walking and rotation can change directions between complete
 * movement cycles. However, waving and dancing cannot be
 * interrupted because the original HIRO library functions
 * must finish executing before a new movement can begin.
 *
 * New commands can still be received while a dance is running,
 * but the robot will not execute them until the dance finishes.
 */
 
#include <HIRO.h>          // Main library for controlling HIRO
#include <HIRO_Motion.h>   // Contains HIRO's walking and dance functions
#include <FreeRTOS.h>      // Allows us to run multiple tasks
#include <task.h>         // Used to create and control tasks
#include <queue.h>        // Allows tasks to send information to each other

// Create the HIRO robot object
HIRO hiro;

// Create a queue to send movement commands between tasks
// The queue will only store the newest command
QueueHandle_t movementQueue;

// Movement commands:
// 0 = Stop
// 1 = Forward
// 2 = Backward
// 3 = Wave
// 4 = Counterclockwise
// 5 = Clockwise
// 6 = Side to Side Worm
// 7 = Side to Side Stretch
// 8 = Push Ups
// 9 = Cabbage Patch
// 10 = Cabbage Patch 2

// ==========================================
// RGB LED FUNCTION
// ==========================================

// Changes the robot's RGB LED to a random color
void rgbRandom() {

  // Give each color a random brightness value
  analogWrite(hiro.red, random(0, 10));
  analogWrite(hiro.green, random(0, 10));
  analogWrite(hiro.blue, random(0, 10));
}


// ==========================================
// TASK 1: SERIAL COMMUNICATION
// Priority: 3 (Highest)
// ==========================================

// This task reads commands from the Serial Monitor
// and sends them to the movement task
void TaskSerial(void *pvParameters) {

  // Stores the numbers typed into the Serial Monitor
  String input = "";

  // Keep this task running forever
  while (true) {

    // Check if the user has sent any information
    while (Serial.available() > 0) {

      // Read one character at a time
      char c = Serial.read();

      // Check if the user pressed Enter
      if (c == '\n' || c == '\r') {

        // Remove any extra spaces
        input.trim();

        // Make sure something was entered
        if (input.length() > 0) {

          // Convert the typed number into an integer
          int command = input.toInt();

          // Check if the command is between 0 and 10
          if (command >= 0 && command <= 10) {

            // Send the command to the movement task
            // This replaces any older command in the queue
            xQueueOverwrite(movementQueue, &command);

            // Display the command that was received
            Serial.print("New command: ");
            Serial.println(command);

          } else {

            // Tell the user if the command is invalid
            Serial.println("Invalid command");
          }
        }

        // Clear the input so another command can be entered
        input = "";

      } else if (input.length() < 8) {

        // Add the character to the input
        input += c;
      }
    }

    // Pause this task for 10 milliseconds
    // This allows other tasks to run
    vTaskDelay(pdMS_TO_TICKS(10));
  }
}


// ==========================================
// TASK 2: ROBOT MOVEMENT
// Priority: 2 (Medium)
// ==========================================

// This task controls the robot's movements
// based on commands received from TaskSerial
void TaskMovement(void *pvParameters) {

  // Stores the movement the robot is currently doing
  int currentCommand = 0;

  // Stores a new command received from the queue
  int newCommand = 0;

  // Stores the previous command so we can detect changes
  int previousCommand = -1;

  // Keep this task running forever
  while (true) {

    // Check if the serial task sent a new command
    if (xQueueReceive(movementQueue, &newCommand, 0)
        == pdTRUE) {

      // Update the movement command
      currentCommand = newCommand;
    }

    // Check if the user changed the movement command
    if (currentCommand != previousCommand) {

      // Return HIRO to its normal standing position
      // before starting a different movement
      neutralStance(hiro);

      // Change the RGB color when a movement starts
      if (currentCommand != 0) {
        rgbRandom();
      }

      // Save the command so we know what was last executed
      previousCommand = currentCommand;
    }

    // Choose which movement to perform
    switch (currentCommand) {

      case 0:

        // Stop moving and stay in the neutral position
        vTaskDelay(pdMS_TO_TICKS(20));
        break;

      case 1:

        // Walk forward one complete walking step/cycle
        easyForward(hiro, 1, 2);
        break;

      case 2:

        // Walk backward one complete walking step/cycle
        easyBackward(hiro, 1, 2);
        break;

      case 3:

        // Perform the waving animation
        wave(hiro);

        // Stop repeating the wave once it finishes
        currentCommand = 0;
        break;

      case 4:

        // Rotate counterclockwise one complete step/cycle
        easyCounterClockwise(hiro, 1, 2);
        break;

      case 5:

        // Rotate clockwise one complete step/cycle
        easyClockwise(hiro, 1, 2);
        break;

      case 6:

        // Perform the side-to-side worm dance
        sideToSideWorm(hiro, 2);

        // Return to idle after the dance finishes
        currentCommand = 0;
        break;

      case 7:

        // Perform the side-to-side stretch
        sideToSideStretch(hiro, 1);

        // Return to idle after the stretch finishes
        currentCommand = 0;
        break;

      case 8:

        // Perform 5 push-ups at speed 2
        pushUps(hiro, 2, 5);

        // Return to idle after all push-ups finish
        currentCommand = 0;
        break;

      case 9:

        // Perform the cabbage patch dance 10 times
        cabbagePatch(hiro, 5, 10);

        // Return to idle after the dance finishes
        currentCommand = 0;
        break;

      case 10:

        // Perform the second cabbage patch dance 10 times
        cabbagePatch2(hiro, 4, 10);

        // Return to idle after the dance finishes
        currentCommand = 0;
        break;
    }

    // Allow other FreeRTOS tasks to run
    taskYIELD();

    /*
     * LIMITATION OF THIS FIRST RTOS VERSION:
     *
     * Walking and rotating are performed one complete
     * step/cycle at a time. This means a new direction
     * can be selected between these steps.
     *
     * However, the wave and dance functions contain
     * loops and delays inside the HIRO library.
     *
     * Because of this, dances and waving CANNOT be
     * interrupted while their routines are running.
     *
     * The Serial task can still receive new commands,
     * but the Movement task must finish the current
     * dance before it can process the new command.
     *
     * A later version will use smaller servo movements
     * to make the dances interruptible as well.
     */
  }
}


// ==========================================
// TASK 3: LED HEARTBEAT
// Priority: 1 (Lowest)
// ==========================================

// This task blinks the built-in LED to show
// that the RTOS is still running
void TaskLED(void *pvParameters) {

  // Keep blinking forever
  while (true) {

    // Turn the LED on
    digitalWrite(LED_BUILTIN, HIGH);

    // Wait 500 milliseconds
    vTaskDelay(pdMS_TO_TICKS(500));

    // Turn the LED off
    digitalWrite(LED_BUILTIN, LOW);

    // Wait another 500 milliseconds
    vTaskDelay(pdMS_TO_TICKS(500));
  }
}


// ==========================================
// SETUP FUNCTION
// ==========================================

// Runs once when the robot is powered on
void setup() {

  // Start serial communication at 9600 baud
  Serial.begin(9600);

  // Set the built-in LED as an output
  pinMode(LED_BUILTIN, OUTPUT);

  // Initialize HIRO's motors and other hardware
  hiro.begin();

  // Move the robot into its normal standing position
  neutralStance(hiro);

  // Set the RGB LED to a random color
  rgbRandom();

  // Create a queue that stores one integer command
  // Only the newest command needs to be saved
  movementQueue = xQueueCreate(1, sizeof(int));

  // Check if the queue was created successfully
  if (movementQueue == NULL) {

    Serial.println("Queue failed");

    // Stop the setup if the queue could not be created
    while (true) {
      delay(1000);
    }
  }

  // ========================================
  // CREATE FREERTOS TASKS
  // ========================================

  // Create the Serial task
  // Priority 3 means it has the highest priority
  BaseType_t serialOK = xTaskCreate(
    TaskSerial,      // Function to run
    "Serial",        // Task name
    1024,            // Stack memory size
    NULL,            // No extra parameters
    3,               // Task priority
    NULL             // No task handle needed
  );

  // Create the Movement task
  // Priority 2 is lower than Serial
  BaseType_t motionOK = xTaskCreate(
    TaskMovement,    // Function to run
    "Movement",      // Task name
    2048,            // Stack memory size
    NULL,            // No extra parameters
    2,               // Task priority
    NULL             // No task handle needed
  );

  // Create the LED task
  // Priority 1 is the lowest of our three tasks
  BaseType_t ledOK = xTaskCreate(
    TaskLED,         // Function to run
    "LED",           // Task name
    512,             // Stack memory size
    NULL,            // No extra parameters
    1,               // Task priority
    NULL             // No task handle needed
  );

  // Check if all three tasks were created successfully
  if (serialOK != pdPASS ||
      motionOK != pdPASS ||
      ledOK != pdPASS) {

    Serial.println("Task creation failed");

    // Stop if one of the tasks could not be created
    while (true) {
      delay(1000);
    }
  }

  // Tell the user that the RTOS tasks are ready
  Serial.println("HIRO FreeRTOS Ready!");
}


// ==========================================
// MAIN LOOP
// ==========================================

void loop() {

  // We do not need to put movement code here
  // because the three FreeRTOS tasks handle everything

  // Pause this loop and allow other tasks to run
  vTaskDelay(pdMS_TO_TICKS(1000));
}

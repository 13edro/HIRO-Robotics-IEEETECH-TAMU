/*
 * File Name: HIRO_Interruptible_FreeRTOS.ino
 * Description: Fully interruptible FreeRTOS movement controller
 * for the H.I.R.O. Model TR-01-A by Takamori Robot.
 *
 * Author: Pedro Maya
 * Date Created: November 2nd, 2026
 *
 * This program uses FreeRTOS to control walking, rotation,
 * waving, and dancing through independent tasks.
 *
 * Unlike the basic version, this program breaks movements
 * into smaller servo movements instead of using the original
 * blocking movement functions.
 *
 * The movement task checks for new commands every 10 milliseconds,
 * allowing the robot to interrupt waving and dancing without
 * waiting for the entire routine to finish.
 *
 * Walking and rotation change directions after lowering the
 * current leg pair. Waving and dancing can be interrupted
 * during their movements.
 *
 * Before starting a new movement, the robot gradually returns
 * toward its neutral standing position.
 *
 * NOTE: Interruptions are controlled through software and
 * are not an emergency stop. Physical stability during
 * movement transitions must still be tested.
 */

#include <Arduino.h>         // Basic Arduino functions like Serial and pinMode
#include <Servo.h>           // Lets us control the servo motors
#include <HIRO.h>            // Contains the HIRO robot class
#include <HIRO_Functions.h>  // Contains move(), which moves a servo a little at a time
#include <HIRO_Walk.h>       // Contains neutralStance() for the starting position
#include <FreeRTOS.h>        // FreeRTOS operating system
#include <task.h>           // Creates tasks and controls their timing
#include <queue.h>          // Lets tasks safely send commands to each other
#include <stdlib.h>         // Provides strtol() to turn text into a number

// ========================================
// HIRO TR-01-A FreeRTOS Movement Controller
// ========================================

// Serial Commands:
// 0  = Stop
// 1  = Forward
// 2  = Backward
// 3  = Wave
// 4  = Counterclockwise
// 5  = Clockwise
// 6  = Side to Side Worm
// 7  = Side to Side Stretch
// 8  = Push Ups
// 9  = Cabbage Patch
// 10 = Cabbage Patch 2

// Create one HIRO robot to control all eight servos
HIRO hiro;

// Queue for receiving the newest command
QueueHandle_t commandQueue = nullptr;

// ========================================
// SERVO CONFIGURATION
// ========================================

// Give each servo a short name so the code is easier to read
// R = right, L = left, F = front, B = back
// S = shoulder, final L = leg
enum Joint : uint8_t {
  RFS, RFL, RBS, RBL,
  LFS, LFL, LBS, LBL,
  JOINT_COUNT
};

// Store pointers to the actual HIRO servo motors
// This lets us choose a motor using a number from the enum above
Servo* servos[JOINT_COUNT];

// Target angle: where each servo needs to go (0 to 180 degrees)
int targetAngle[JOINT_COUNT];
// Increment: how many degrees each servo moves during one update
int incrementAngle[JOINT_COUNT];
// Assigned: true if this servo is part of the current movement step
bool assigned[JOINT_COUNT];

// ========================================
// MOVEMENT STATES
// ========================================

// These states tell us what kind of motion HIRO is doing
// IDLE means waiting; RETURN_NEUTRAL means returning to standing
enum Mode : uint8_t {
  IDLE,
  WALK,
  WAVE,
  EXERCISE,
  RETURN_NEUTRAL
};

// HIRO starts in idle mode
Mode mode = IDLE;

// The command HIRO is currently performing
int currentCommand = 0;
// The newest command requested by the user
int desiredCommand = 0;

// Stage: which small part of the current movement is happening
uint8_t stage = 0;
// How many dance or wave repetitions are already finished
uint8_t completedCycles = 0;
// Total repetitions wanted for that movement
uint8_t goalCycles = 0;

// ========================================
// SERVO CONTROL FUNCTIONS
// ========================================

// Clear the previous servo targets
void clearPose() {

  for (int i = 0; i < JOINT_COUNT; i++) {
    assigned[i] = false;
  }
}

// Set a target for one servo
void jointTarget(Joint joint, int angle, int step = 2) {

  // Keep the target within the safe command range of 0 to 180
  targetAngle[joint] = constrain(angle, 0, 180);
  // Make sure the servo moves by at least one degree per update
  incrementAngle[joint] = max(1, abs(step));
  // Mark this servo as active for this stage
  assigned[joint] = true;
}

// Move each assigned servo one increment
// This is non-blocking.
bool advancePose() {

  // Start by assuming all servos have reached their targets
  bool allDone = true;

  // Check every servo, but only move the ones used in this stage
  for (int i = 0; i < JOINT_COUNT; i++) {

    if (assigned[i]) {

      // Move this servo one small amount toward its target
      bool done = move(
        *servos[i],
        targetAngle[i],
        incrementAngle[i]
      );

      // If even one servo still needs to move, this stage is not done
      if (!done) {
        allDone = false;
      }
    }
  }

  // The next stage starts only when every active servo is done
  return allDone;
}

// ========================================
// NEUTRAL STANCE
// ========================================

// Set the target angles for HIRO's normal standing position
// This function sets targets; it does NOT move all servos instantly
void neutralPose() {

  clearPose();

  jointTarget(RFS, 90);
  jointTarget(RFL, 0);

  jointTarget(RBS, 90);
  jointTarget(RBL, 0);

  jointTarget(LFS, 90);
  jointTarget(LFL, 180);

  jointTarget(LBS, 90);
  jointTarget(LBL, 180);
}

// Begin gradually moving the robot back to a standing position
void startNeutral() {

  // Tell the controller that it is returning to neutral
  mode = RETURN_NEUTRAL;
  currentCommand = 0;

  neutralPose();
}

// ========================================
// WALKING AND ROTATION
// ========================================

// Six phases:
// 0 - Raise first diagonal pair
// 1 - Swing / rotate
// 2 - Lower first diagonal pair
// 3 - Raise second diagonal pair
// 4 - Swing / rotate
// 5 - Lower second diagonal pair

// Pick the servo targets for one part of walking or turning
// cmd = movement direction, s = current stage (0 through 5)
void walkPose(int cmd, uint8_t s) {

  clearPose();

  switch (s) {

    case 0:
      // Lift the right-front and left-back diagonal pair
      jointTarget(RFL, 30);
      jointTarget(LBL, 150);
      break;

    case 1:
    case 4: {

      // True when moving the first pair; false for the second pair
      bool first = (s == 1);

      if (cmd == 1 || cmd == 2) {

        // Forward and backward
        // Change the sign to move in the right direction
        // 25 degrees is the original walking stride
        int stride =
          ((cmd == 1) == first) ? 25 : -25;

        jointTarget(RFS, 90 + stride);
        jointTarget(LBS, 90 - stride);
        jointTarget(LFS, 90 + stride);
        jointTarget(RBS, 90 - stride);

      } else {

        // Clockwise and counterclockwise
        // Rotating uses a 20-degree twist instead of 25
        int stride =
          ((cmd == 4) == first) ? 20 : -20;

        jointTarget(RFS, 90 + stride);
        jointTarget(LBS, 90 + stride);
        jointTarget(LFS, 90 - stride);
        jointTarget(RBS, 90 - stride);
      }

      break;
    }

    case 2:
      // Put the first pair of legs back down
      jointTarget(RFL, 0);
      jointTarget(LBL, 180);
      break;

    case 3:
      // Lift the left-front and right-back diagonal pair
      jointTarget(LFL, 150);
      jointTarget(RBL, 30);
      break;

    case 5:
      // Put the second pair of legs back down
      jointTarget(LFL, 180);
      jointTarget(RBL, 0);
      break;
  }
}

// ========================================
// WAVE CHOREOGRAPHY
// ========================================

// Wave is divided into stages so a new command can interrupt it
// Instead of calling the original long wave() function, we set targets
void wavePose(uint8_t s) {

  clearPose();

  switch (s) {

    case 0:
      // Shift the robot's pose so it can balance while waving
      jointTarget(LBL, 150);
      jointTarget(RBS, 120);
      jointTarget(LFS, 60);
      break;

    case 1:
      // Raise arm
      jointTarget(RFL, 130);
      break;

    case 2:
      // Pull arm backward
      jointTarget(RFS, 30);
      break;

    case 3:
      // Lift the arm higher to the top of the wave
      jointTarget(RFL, 180);
      break;

    case 4:
      // Bring the arm lower to complete one wave
      jointTarget(RFL, 130);
      break;

    case 5:
      // Return shoulder
      jointTarget(RFS, 90);
      break;

    case 6:
      // Lower arm
      jointTarget(RFL, 45);
      break;
  }
}

// ========================================
// EXERCISE AND DANCE MOVEMENTS
// ========================================

// All dances and exercises use this same step-by-step method
// cmd selects the dance; s selects the next part of that dance
void exercisePose(int cmd, uint8_t s) {

  clearPose();

  // ------------------------------------
  // COMMAND 6: SIDE TO SIDE WORM
  // COMMAND 7: SIDE TO SIDE STRETCH
  // ------------------------------------

  if (cmd == 6 || cmd == 7) {

    // The worm moves 2 degrees per update; the stretch moves 1
    int speed = (cmd == 6) ? 2 : 1;

    if (s == 0) {
      // Start setup: lift one diagonal leg pair
      jointTarget(LFL, 150, 2);
      jointTarget(RBL, 30, 2);
    }

    else if (s == 1) {
      // Move shoulders to make a sideways stance
      jointTarget(LFS, 135, 2);
      jointTarget(RBS, 135, 2);
    }

    else if (s == 2) {
      // Lower the lifted legs again
      jointTarget(LFL, 180, 2);
      jointTarget(RBL, 0, 2);
    }

    else if (s == 3) {
      // Lift the other diagonal pair
      jointTarget(RFL, 30, 2);
      jointTarget(LBL, 150, 2);
    }

    else if (s == 4) {
      // Set the other two shoulders to the sideways pose
      jointTarget(RFS, 45, 2);
      jointTarget(LBS, 45, 2);
    }

    else if (s == 5) {
      // Lower the second lifted pair; setup is finished
      jointTarget(RFL, 0, 2);
      jointTarget(LBL, 180, 2);
    }

    else if (s == 6) {
      // Lean the legs toward one side

      jointTarget(RFL, 0, speed);
      jointTarget(RBL, 0, speed);

      jointTarget(
        LFL,
        cmd == 6 ? 90 : 135,
        speed
      );

      jointTarget(
        LBL,
        cmd == 6 ? 90 : 135,
        speed
      );
    }

    else if (s == 7) {
      // Lean back toward the other side

      jointTarget(
        RFL,
        cmd == 6 ? 90 : 45,
        speed
      );

      jointTarget(
        RBL,
        cmd == 6 ? 90 : 45,
        speed
      );

      jointTarget(LFL, 180, speed);
      jointTarget(LBL, 180, speed);
    }
  }

  // ------------------------------------
  // COMMAND 8: PUSH UPS
  // ------------------------------------

  else if (cmd == 8) {

    // Push-up movements use 2 degrees per servo update
    const int v = 2;

    switch (s) {

      case 0:
        // Lift diagonal legs to begin push-up setup
        jointTarget(LFL, 150, v);
        jointTarget(RBL, 30, v);
        break;

      case 1:
        // Move the shoulders into the push-up position
        jointTarget(RBS, 45, v);
        jointTarget(LFS, 140, v);
        break;

      case 2:
        // Set the lifted legs back down
        jointTarget(LFL, 180, v);
        jointTarget(RBL, 0, v);
        break;

      case 3:
        // Raise the second pair for the rest of setup
        jointTarget(RFL, 30, v);
        jointTarget(LBL, 150, v);
        break;

      case 4:
        // Adjust the other shoulders
        jointTarget(RFS, 40, v);
        jointTarget(LBS, 135, v);
        break;

      case 5:
        // Place the second pair back down
        jointTarget(RFL, 0, v);
        jointTarget(LBL, 180, v);
        break;

      case 6:
        // Set the back legs for the push-up position
        jointTarget(RBL, 45, v);
        jointTarget(LBL, 135, v);
        break;

      case 7:
        // Push down
        jointTarget(RFL, 45, v);
        jointTarget(LFL, 135, v);
        break;

      case 8:
        // Push up
        jointTarget(RFL, 0, v);
        jointTarget(LFL, 180, v);
        break;
    }
  }

  // ------------------------------------
  // COMMAND 9: CABBAGE PATCH
  // ------------------------------------

  else if (cmd == 9) {

    // Each active servo moves up to 5 degrees per update
    const int v = 5;

    switch (s) {

      case 0:
        // Raise the left side and turn the shoulders
        jointTarget(LFL, 0, v);
        jointTarget(LFS, 40, v);
        jointTarget(RBS, 35, v);
        jointTarget(LBS, 35, v);
        break;

      case 1:
        // Bring the left leg back to its starting angle
        jointTarget(LFL, 180, v);
        break;

      case 2:
        // Raise the right side and turn the shoulders
        jointTarget(RFL, 180, v);
        jointTarget(RFS, 140, v);
        jointTarget(RBS, 145, v);
        jointTarget(LBS, 145, v);
        break;

      case 3:
        // Return the right leg to its starting angle
        jointTarget(RFL, 0, v);
        break;
    }
  }

  // ------------------------------------
  // COMMAND 10: CABBAGE PATCH 2
  // ------------------------------------

  else if (cmd == 10) {

    // This dance uses a faster 4-degree update for most joints
    const int v = 4;

    if (s == 0) {
      // First half of the dance: move left-side legs and shoulders

      jointTarget(LFL, 0, v);
      jointTarget(LFS, 40, v);
      jointTarget(RBL, 20, v);
      jointTarget(LBL, 180, v);
      jointTarget(RFS, 90, v);
      jointTarget(RFL, 0, v * 3);
    }

    else {
      // Second half: switch to the right side

      jointTarget(RFL, 180, v);
      jointTarget(RFS, 140, v);
      jointTarget(LBL, 160, v);
      jointTarget(RBL, 0, v);
      jointTarget(LFS, 90, v);
      jointTarget(LFL, 180, v * 3);
    }
  }
}

// ========================================
// START A MOVEMENT
// ========================================

// Start the command selected by the user
// Reset the stage and repetition counter so it starts at the beginning
void startCommand(int cmd) {

  currentCommand = cmd;
  stage = 0;
  completedCycles = 0;

  if (cmd == 0) {
    startNeutral();
    return;
  }

  if (
    (cmd >= 1 && cmd <= 2) ||
    cmd == 4 ||
    cmd == 5
  ) {

    // Walking and turning share the same six-stage pattern
    mode = WALK;
    walkPose(cmd, stage);
  }

  else if (cmd == 3) {

    // Wave a random number of times between 3 and 5
    mode = WAVE;
    goalCycles = random(3, 6);

    wavePose(stage);
  }

  else {

    // All five dance/exercise commands use the same mode
    mode = EXERCISE;

    // Worm, stretch, and push-ups repeat 5 times
    // Both cabbage patch dances repeat 10 times
    goalCycles =
      (cmd == 6 || cmd == 7 || cmd == 8)
      ? 5 : 10;

    exercisePose(cmd, stage);
  }
}

// ========================================
// MOVE TO THE NEXT PHASE
// ========================================

// Called when the active servos have reached their target angles
// Chooses the next part of the movement, or finishes it
void finishPose() {

  // Neutral targets are reached: HIRO can accept its next command
  if (mode == RETURN_NEUTRAL) {

    mode = IDLE;
    return;
  }

  // ------------------------------------
  // WALKING / ROTATION
  // ------------------------------------

  if (mode == WALK) {

    // Switch after lowering a leg pair
    if (
      (stage == 2 || stage == 5) &&
      desiredCommand != currentCommand
    ) {

      startNeutral();
      return;
    }

    // Go to the next walking stage, then start again after stage 5
    stage = (stage + 1) % 6;
    walkPose(currentCommand, stage);

    return;
  }

  // ------------------------------------
  // WAVE
  // ------------------------------------

  if (mode == WAVE) {

    // Stage 4 finishes one up/down wave motion
    if (stage == 4) {

      // Record that one complete repetition is finished
      completedCycles++;

      if (completedCycles < goalCycles) {
        stage = 3;
      } else {
        stage = 5;
      }
    }

    else if (stage == 6) {

      desiredCommand = 0;
      startNeutral();
      return;
    }

    else {
      stage++;
    }

    wavePose(stage);
    return;
  }

  // ------------------------------------
  // EXERCISES / DANCES
  // ------------------------------------

  if (mode == EXERCISE) {

    const int cmd = currentCommand;

    // Setup stages run once; these are the stages to repeat
    const uint8_t firstRepeat =
      (cmd == 6 || cmd == 7)
      ? 6 : (cmd == 8 ? 7 : 0);

    // This is the final stage of one complete repetition
    const uint8_t lastStage =
      (cmd == 6 || cmd == 7)
      ? 7 : (cmd == 8 ? 8 :
      (cmd == 9 ? 3 : 1));

    if (stage == lastStage) {

      completedCycles++;

      if (completedCycles >= goalCycles) {

        desiredCommand = 0;
        startNeutral();
        return;
      }

      stage = firstRepeat;

    } else {
      stage++;
    }

    exercisePose(cmd, stage);
  }
}

// ========================================
// TASK 1: SERIAL INPUT
// PRIORITY 3
// ========================================

// This task is responsible only for reading the Serial Monitor
// It can receive a new command while another task moves the robot
void TaskSerial(void* unused) {

  // Save the typed characters until Enter is pressed
  char buffer[12];
  uint8_t length = 0;

  while (true) {

    while (Serial.available()) {

      // Read one character from the serial connection
      char ch = Serial.read();

      // Newline means the user has finished entering a command
      if (ch == '\n' || ch == '\r') {

        if (length > 0) {

          buffer[length] = '\0';

          // Convert typed text into a number; end checks leftover text
          char* end;
          long cmd = strtol(buffer, &end, 10);

          if (
            *end == '\0' &&
            cmd >= 0 &&
            cmd <= 10
          ) {

            // Make sure the command is an integer from 0 to 10
            int value = (int)cmd;

            // Newest command replaces the old one
            xQueueOverwrite(
              commandQueue,
              &value
            );

            Serial.print("Requested: ");
            Serial.println(value);

          } else {

            Serial.println(
              "Valid commands: 0 to 10"
            );
          }
        }

        // Reset the buffer so the next command starts fresh
        length = 0;
      }

      else if (
        length < sizeof(buffer) - 1
      ) {

        buffer[length++] = ch;
      }

      else {
        length = 0;
      }
    }

    // Check for more serial data after a short pause
    vTaskDelay(pdMS_TO_TICKS(10));
  }
}

// ========================================
// TASK 2: MOVEMENT CONTROL
// PRIORITY 2
// ========================================

// This is the only task that tells the servos to move
// It checks commands and makes one small movement every update
void TaskMotion(void* unused) {

  // Remember when this task started so updates stay evenly spaced
  TickType_t lastWake =
    xTaskGetTickCount();

  int received;

  while (true) {

    // Check if a new command was received
    if (
      xQueueReceive(
        commandQueue,
        &received,
        0
      ) == pdTRUE
    ) {

      // Save the newest command, replacing whatever was requested
      desiredCommand = received;

      // Interrupt wave and dances
      if (
        (mode == WAVE || mode == EXERCISE) &&
        desiredCommand != currentCommand
      ) {

        // Cancel the rest of the wave/dance and return toward neutral
        startNeutral();
      }
    }

    // Start a new command when idle
    if (
      mode == IDLE &&
      desiredCommand != 0
    ) {

      // Start the waiting command after the neutral pose is reached
      startCommand(desiredCommand);
    }

    // Update servo positions once
    if (
      mode != IDLE &&
      advancePose()
    ) {

      // All active servos reached their targets: advance to next stage
      finishPose();
    }

    // Run every 10 milliseconds
    // Try to run motion updates every 10 ms, unlike a long delay() loop
    vTaskDelayUntil(
      &lastWake,
      pdMS_TO_TICKS(10)
    );
  }
}

// ========================================
// TASK 3: LED HEARTBEAT
// PRIORITY 1
// ========================================

// Blink the built-in LED while the RTOS is running
// This task is separate, so the LED can blink during movement
void TaskLED(void* unused) {

  while (true) {

    digitalWrite(LED_BUILTIN, HIGH);

    vTaskDelay(pdMS_TO_TICKS(500));

    digitalWrite(LED_BUILTIN, LOW);

    vTaskDelay(pdMS_TO_TICKS(500));
  }
}

// ========================================
// ARDUINO SETUP
// ========================================

// setup() runs once when the robot powers on or resets
void setup() {

  // Open the serial connection at 9600 baud
  Serial.begin(9600);

  // Let the onboard LED turn on and off
  pinMode(LED_BUILTIN, OUTPUT);

  // Initialize HIRO hardware
  // Connect all eight HIRO servos using the robot's normal pins
  hiro.begin();

  // Assign servo objects
  servos[RFS] = &hiro.rfs;
  servos[RFL] = &hiro.rfl;

  servos[RBS] = &hiro.rbs;
  servos[RBL] = &hiro.rbl;

  servos[LFS] = &hiro.lfs;
  servos[LFL] = &hiro.lfl;

  servos[LBS] = &hiro.lbs;
  servos[LBL] = &hiro.lbl;

  // Initialize standing position
  // Use the original HIRO function once at startup
  // It is blocking here, but tasks have not started yet
  neutralStance(hiro);

  clearPose();

  // Create command queue
  // One-slot queue keeps only the latest command
  commandQueue = xQueueCreate(
    1,
    sizeof(int)
  );

  // If memory is not available for the queue, do not continue
  if (commandQueue == NULL) {

    Serial.println(
      "Queue creation failed"
    );

    while (true) {
      delay(1000);
    }
  }

  // Create serial task
  // Task priority 3: read commands first
  BaseType_t a = xTaskCreate(
    TaskSerial,
    "Serial",
    2048,
    NULL,
    3,
    NULL
  );

  // Create movement task
  // Task priority 2: update the servo motors
  BaseType_t b = xTaskCreate(
    TaskMotion,
    "Motion",
    4096,
    NULL,
    2,
    NULL
  );

  // Create LED task
  // Task priority 1: blink an LED in the background
  BaseType_t c = xTaskCreate(
    TaskLED,
    "LED",
    1024,
    NULL,
    1,
    NULL
  );

  // Check for task creation errors
  // pdPASS means the task was created successfully
  if (
    a != pdPASS ||
    b != pdPASS ||
    c != pdPASS
  ) {

    Serial.println(
      "Task creation failed"
    );

    while (true) {
      delay(1000);
    }
  }

  Serial.println(
    "HIRO FreeRTOS Ready!"
  );
}

// ========================================
// ARDUINO LOOP
// ========================================

// FreeRTOS tasks do the main work, so Arduino loop() stays simple
void loop() {

  // FreeRTOS tasks handle robot operation
  vTaskDelay(pdMS_TO_TICKS(1000));
}

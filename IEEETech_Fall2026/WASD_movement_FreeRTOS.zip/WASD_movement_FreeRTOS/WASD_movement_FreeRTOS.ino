
/*
 * File Name: HIRO_Basic_Ultrasonic_RTOS.ino
 * Description: Basic FreeRTOS movement and obstacle detection
 * for H.I.R.O. Model TR-01-A by Takamori Robot.
 *
 * Author: Pedro Maya
 * Date: November 9, 2026
 *
 * Uses the original HIRO libraries for walking and rotation.
 * An experimental sideways movement is included for A and D.
 *
 * The ultrasonic sensor stops movement when an object
 * is 20 cm or closer. Backward movement is still allowed.
 *
 * Movements finish their current cycle before switching.
 * This is not an immediate emergency stop.
 */

#include <HIRO.h>
#include <HIRO_Motion.h>
#include <HIRO_Functions.h>
#include <FreeRTOS.h>
#include <task.h>
#include <queue.h>

HIRO hiro;

// ========================================
// SENSOR SETTINGS
// ========================================

const int TRIG_PIN = 9;
const int ECHO_PIN = 22;

const float STOP_DISTANCE = 20.0;
const float CLEAR_DISTANCE = 25.0;

// Queue for keyboard commands
QueueHandle_t movementQueue;

// Queue for obstacle detection
QueueHandle_t sensorQueue;


// ========================================
// SIDEWAYS MOVEMENT
// ========================================

// HIRO does not have a built-in sideways function.
// This experimental routine uses the original
// HIRO leg-lifting and lowering functions.

void swingSideways(char direction, bool firstPair) {

  int lateral =
    ((direction == 'a') == firstPair) ? 15 : -15;

  bool done = false;
  int count = 0;

  // Move the shoulders a little at a time
  while (!done && count < 90) {

    bool a = move(hiro.rfs, 90 + lateral, 2);
    bool b = move(hiro.rbs, 90 + lateral, 2);
    bool c = move(hiro.lfs, 90 - lateral, 2);
    bool d = move(hiro.lbs, 90 - lateral, 2);

    done = a && b && c && d;

    count++;
    delay(5);
  }
}

void moveSideways(char direction) {

  // Lift first diagonal pair
  raise_RFL_LBL(hiro, 60, 2);

  // Move shoulders sideways
  swingSideways(direction, true);

  // Lower first pair
  lower_RFL_LBL(hiro, 0, 2);

  // Lift second diagonal pair
  raise_LFL_RBL(hiro, 60, 2);

  // Move shoulders the opposite way
  swingSideways(direction, false);

  // Lower second pair
  lower_LFL_RBL(hiro, 0, 2);
}


// ========================================
// ULTRASONIC SENSOR FUNCTION
// ========================================

// Measures distance in centimeters
// Returns -1 if no echo is received

float readDistance() {

  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);

  // Send a short ultrasonic pulse
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  // Measure how long the echo takes to return
  unsigned long duration =
    pulseIn(ECHO_PIN, HIGH, 25000UL);

  if (duration == 0) {
    return -1;
  }

  // Convert travel time to distance
  return duration * 0.0343 / 2.0;
}


// ========================================
// TASK 1: SERIAL COMMUNICATION
// Priority 3
// ========================================

// Reads keyboard commands from Serial Monitor

void TaskSerial(void *pvParameters) {

  while (true) {

    if (Serial.available() > 0) {

      char command = Serial.read();

      // Convert uppercase to lowercase
      if (command >= 'A' && command <= 'Z') {
        command += 32;
      }

      // X and 0 both stop the robot
      if (command == 'x') {
        command = '0';
      }

      // Accept only valid movement commands
      if (command == 'w' || command == 's' ||
          command == 'a' || command == 'd' ||
          command == 'q' || command == 'e' ||
          command == '0') {

        // Store the newest command
        xQueueOverwrite(movementQueue, &command);

        Serial.print("Command: ");
        Serial.println(command);
      }
    }

    vTaskDelay(pdMS_TO_TICKS(10));
  }
}


// ========================================
// TASK 2: MOVEMENT CONTROL
// Priority 2
// ========================================

// Uses HIRO's original movement functions.
// The robot checks for new commands between
// complete walking or rotation cycles.

void TaskMovement(void *pvParameters) {

  char currentCommand = '0';
  char newCommand = '0';
  char requestedCommand = '0';

  // Start blocked until the sensor is checked
  bool obstacleClose = true;

  while (true) {

    // Check for the newest movement command
    if (xQueueReceive(movementQueue, &newCommand, 0)
        == pdTRUE) {

      requestedCommand = newCommand;
    }

    // Get the latest ultrasonic sensor status
    xQueuePeek(sensorQueue, &obstacleClose, 0);

    // If an obstacle is too close, stop movement.
    // Backward movement is still allowed.
    if (obstacleClose && requestedCommand != 's') {
      requestedCommand = '0';
    }

    // Only return to neutral when changing commands
    if (requestedCommand != currentCommand) {

      neutralStance(hiro);

      currentCommand = requestedCommand;
    }

    // Run one complete movement cycle
    switch (currentCommand) {

      case 'w':
        easyForward(hiro, 1, 2);
        break;

      case 's':
        easyBackward(hiro, 1, 2);
        break;

      case 'a':
        // Experimental strafe left
        moveSideways('a');
        break;

      case 'd':
        // Experimental strafe right
        moveSideways('d');
        break;

      case 'q':
        easyCounterClockwise(hiro, 1, 2);
        break;

      case 'e':
        easyClockwise(hiro, 1, 2);
        break;

      case '0':
        // Stay in neutral position
        vTaskDelay(pdMS_TO_TICKS(20));
        break;
    }

    // Give other tasks time to run
    taskYIELD();
  }
}


// ========================================
// TASK 3: ULTRASONIC SENSOR
// Priority 3
// ========================================

// Checks the distance in front of HIRO
// while the movement task is running

void TaskUltrasonic(void *pvParameters) {

  bool obstacleClose = true;

  while (true) {

    float distance = readDistance();

    // No echo means the sensor reading is unknown
    // Stop as a precaution
    if (distance < 0) {
      obstacleClose = true;
    }

    // Object is too close
    else if (distance <= STOP_DISTANCE) {
      obstacleClose = true;
    }

    // Object is far enough away
    else if (distance >= CLEAR_DISTANCE) {
      obstacleClose = false;
    }

    // Share the result with the movement task
    xQueueOverwrite(sensorQueue, &obstacleClose);

    // Wait before checking again
    vTaskDelay(pdMS_TO_TICKS(70));
  }
}


// ========================================
// TASK 4: LED HEARTBEAT
// Priority 1
// ========================================

// Blinks to show that FreeRTOS is running

void TaskLED(void *pvParameters) {

  while (true) {

    digitalWrite(LED_BUILTIN, HIGH);
    vTaskDelay(pdMS_TO_TICKS(500));

    digitalWrite(LED_BUILTIN, LOW);
    vTaskDelay(pdMS_TO_TICKS(500));
  }
}


// ========================================
// SETUP
// ========================================

void setup() {

  Serial.begin(9600);

  pinMode(LED_BUILTIN, OUTPUT);

  // Set up ultrasonic sensor
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  digitalWrite(TRIG_PIN, LOW);

  // Initialize HIRO hardware
  hiro.begin();

  // Start in neutral position
  neutralStance(hiro);

  // Create the command and sensor queues
  movementQueue = xQueueCreate(1, sizeof(char));
  sensorQueue = xQueueCreate(1, sizeof(bool));

  if (movementQueue == NULL || sensorQueue == NULL) {
    Serial.println("Queue creation failed");
    while (true) {
      delay(1000);
    }
  }

  // Block movement until a safe reading is received
  bool initiallyBlocked = true;
  xQueueOverwrite(sensorQueue, &initiallyBlocked);

  // Create FreeRTOS tasks
  BaseType_t serialOK = xTaskCreate(
    TaskSerial, "Serial", 1024, NULL, 3, NULL
  );

  BaseType_t movementOK = xTaskCreate(
    TaskMovement, "Movement", 2048, NULL, 2, NULL
  );

  BaseType_t sensorOK = xTaskCreate(
    TaskUltrasonic, "Ultrasonic", 2048, NULL, 3, NULL
  );

  BaseType_t ledOK = xTaskCreate(
    TaskLED, "LED", 512, NULL, 1, NULL
  );

  // Check if all tasks were created
  if (serialOK != pdPASS ||
      movementOK != pdPASS ||
      sensorOK != pdPASS ||
      ledOK != pdPASS) {

    Serial.println("Task creation failed");

    while (true) {
      delay(1000);
    }
  }

  Serial.println("HIRO FreeRTOS Ready!");
  Serial.println("W A S D Q E = Movement");
  Serial.println("X = Stop");
  Serial.println("Ultrasonic sensor enabled");
}


// ========================================
// MAIN LOOP
// ========================================

void loop() {

  // FreeRTOS tasks handle everything
  vTaskDelay(pdMS_TO_TICKS(1000));
}
